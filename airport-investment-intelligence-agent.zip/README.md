# Airport Investment Intelligence Agent

A chat agent that helps analysts find US airports where terminal or capacity projects should pay off. The LLM (DeepSeek) interprets the question and writes the answer; every number, score and ranking comes from deterministic TypeScript over public BTS, FAA and OurAirports data.

- Live app: https://stingray-app-nh4r6.ondigitalocean.app/
- GitHub repo: https://github.com/SaltyByte/airport-investment-intelligence-agent

## Try it without installing anything

Open the live app and ask, for example:

- Which airports in New England are strong candidates for terminal expansion?
- Compare LA and Santa Ana airport congestion levels.
- What is the percentage of long haul flights out of Anchorage airport?
- What is the unmet flight demand in SFO airport and why?

## Run it from this zip

The project is in `airport-investment-intelligence-agent/`. It contains the full source, the lockfile and the airport data snapshot (`apps/server/data/snapshot.json.gz`), so there is no database and nothing else to download. You need a DeepSeek API key ([get one here](https://platform.deepseek.com/api_keys); the account needs a positive balance).

### Option A: Node (Node 24+ and pnpm)

```sh
cd airport-investment-intelligence-agent
npm install -g pnpm    # pnpm 10+ switches itself to the pinned 11.3.0
pnpm install
cp .env.example .env   # paste your key after DEEPSEEK_API_KEY=
pnpm dev
```

Open http://localhost:5173 (the API runs on :4100; the web app proxies `/api` to it).

### Option B: Docker

```sh
cd airport-investment-intelligence-agent
docker build -t airport-agent .
docker run --rm -p 8080:8080 -e DEEPSEEK_API_KEY=<your key> airport-agent
```

Open http://localhost:8080.

### Other commands

- `pnpm check`: lint, typecheck and tests (no API key needed).
- `pnpm eval`: runs the four example questions against the live model and checks every number is grounded in tool output (uses the API key).

## More detail

See `airport-investment-intelligence-agent/README.md` for troubleshooting and layout, `docs/design.md` for the scoring methodology and architecture, and `GLOSSARY.md` for term definitions.
